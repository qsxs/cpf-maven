/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.datastore.core

import androidx.annotation.RestrictTo

/**
 * In Native this function is NO-OP, and returns the provided [exception].
 *
 * @param parentDirPath Path of the parent directory containing the [DataStore] file.
 * @param exception the `FileNotFoundException` encountered
 * @return The provided [exception].
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public actual fun wrapExceptionIfDueToDirectBoot(
    parentDirPath: String?,
    exception: Exception,
): Exception = exception
