package androidx.paging.internal

// OHOS SDK pthread.h 定义递归锁类型，复用两种 ABI 已有的 posix 平台声明。
internal actual val PTHREAD_MUTEX_RECURSIVE: Int = platform.posix.PTHREAD_MUTEX_RECURSIVE
