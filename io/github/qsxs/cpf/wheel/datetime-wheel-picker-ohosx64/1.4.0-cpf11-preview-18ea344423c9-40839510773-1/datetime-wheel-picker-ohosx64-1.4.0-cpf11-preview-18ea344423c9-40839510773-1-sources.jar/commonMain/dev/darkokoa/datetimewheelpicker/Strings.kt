package dev.darkokoa.datetimewheelpicker

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.intl.Locale
import cafe.adriel.lyricist.Lyricist
import cafe.adriel.lyricist.LanguageTag
import cafe.adriel.lyricist.rememberStrings
import cafe.adriel.lyricist.ProvideStrings
import dev.darkokoa.datetimewheelpicker.strings.UzArabStrings
import dev.darkokoa.datetimewheelpicker.strings.IdStrings
import dev.darkokoa.datetimewheelpicker.strings.RoStrings
import dev.darkokoa.datetimewheelpicker.strings.JaStrings
import dev.darkokoa.datetimewheelpicker.strings.EsStrings
import dev.darkokoa.datetimewheelpicker.strings.TrStrings
import dev.darkokoa.datetimewheelpicker.strings.NbStrings
import dev.darkokoa.datetimewheelpicker.strings.DeStrings
import dev.darkokoa.datetimewheelpicker.strings.ElStrings
import dev.darkokoa.datetimewheelpicker.strings.NoStrings
import dev.darkokoa.datetimewheelpicker.strings.ZhStrings
import dev.darkokoa.datetimewheelpicker.strings.FiStrings
import dev.darkokoa.datetimewheelpicker.strings.UzStrings
import dev.darkokoa.datetimewheelpicker.strings.KoStrings
import dev.darkokoa.datetimewheelpicker.strings.RuStrings
import dev.darkokoa.datetimewheelpicker.strings.PtStrings
import dev.darkokoa.datetimewheelpicker.strings.FrStrings
import dev.darkokoa.datetimewheelpicker.strings.PlStrings
import dev.darkokoa.datetimewheelpicker.strings.NlStrings
import dev.darkokoa.datetimewheelpicker.strings.ThStrings
import dev.darkokoa.datetimewheelpicker.strings.HiStrings
import dev.darkokoa.datetimewheelpicker.strings.BnStrings
import dev.darkokoa.datetimewheelpicker.strings.FaStrings
import dev.darkokoa.datetimewheelpicker.strings.ViStrings
import dev.darkokoa.datetimewheelpicker.strings.UkStrings
import dev.darkokoa.datetimewheelpicker.strings.EnStrings
import dev.darkokoa.datetimewheelpicker.strings.DaStrings
import dev.darkokoa.datetimewheelpicker.strings.UzCyrlStrings
import dev.darkokoa.datetimewheelpicker.strings.SvStrings
import dev.darkokoa.datetimewheelpicker.strings.ArStrings
import dev.darkokoa.datetimewheelpicker.strings.HeStrings
import dev.darkokoa.datetimewheelpicker.strings.ItStrings
import dev.darkokoa.datetimewheelpicker.strings.CsStrings
import dev.darkokoa.datetimewheelpicker.strings.Strings

internal val Strings: Map<LanguageTag, Strings> = mapOf(
    "uz-Arab" to UzArabStrings,
    "id" to IdStrings,
    "ro" to RoStrings,
    "ja" to JaStrings,
    "es" to EsStrings,
    "tr" to TrStrings,
    "nb" to NbStrings,
    "de" to DeStrings,
    "el" to ElStrings,
    "no" to NoStrings,
    "zh" to ZhStrings,
    "fi" to FiStrings,
    "uz" to UzStrings,
    "ko" to KoStrings,
    "ru" to RuStrings,
    "pt" to PtStrings,
    "fr" to FrStrings,
    "pl" to PlStrings,
    "nl" to NlStrings,
    "th" to ThStrings,
    "hi" to HiStrings,
    "bn" to BnStrings,
    "fa" to FaStrings,
    "vi" to ViStrings,
    "uk" to UkStrings,
    "en" to EnStrings,
    "da" to DaStrings,
    "uz-Cyrl" to UzCyrlStrings,
    "sv" to SvStrings,
    "ar" to ArStrings,
    "he" to HeStrings,
    "it" to ItStrings,
    "cs" to CsStrings
)

internal val LocalStrings: ProvidableCompositionLocal<Strings> = 
    staticCompositionLocalOf { EnStrings }



@Composable
internal fun rememberStrings(
    defaultLanguageTag: LanguageTag = "en",
    currentLanguageTag: LanguageTag = Locale.current.toLanguageTag(),
): Lyricist<Strings> =
    rememberStrings(Strings, defaultLanguageTag, currentLanguageTag)

@Composable
internal fun ProvideStrings(
    lyricist: Lyricist<Strings> = rememberStrings(),
    content: @Composable () -> Unit
) {
    ProvideStrings(lyricist, LocalStrings, content)
}

internal fun getLocaleStrings(locale: Locale = Locale.current): Strings {
    return Strings[locale.toLanguageTag()] ?: EnStrings
}                