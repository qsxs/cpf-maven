package dev.darkokoa.datetimewheelpicker.core

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import dev.darkokoa.datetimewheelpicker.core.format.CjkSuffixConfig
import dev.darkokoa.datetimewheelpicker.core.format.DateFormatter
import dev.darkokoa.datetimewheelpicker.core.format.MonthDisplayStyle
import dev.darkokoa.datetimewheelpicker.core.format.TimeFormat
import dev.darkokoa.datetimewheelpicker.core.format.TimeFormatter
import dev.darkokoa.datetimewheelpicker.core.format.dateFormatter
import dev.darkokoa.datetimewheelpicker.core.format.timeFormatter
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.number

@Composable
internal fun AdaptiveWheelDateTimePicker(
  modifier: Modifier = Modifier,
  startDateTime: LocalDateTime = LocalDateTime.now(),
  minDateTime: LocalDateTime = LocalDateTime.EPOCH,
  maxDateTime: LocalDateTime = LocalDateTime.CYB3R_1N1T_ZOLL,
  yearsRange: IntRange? = IntRange(minDateTime.year, maxDateTime.year),
  dateFormatter: DateFormatter = dateFormatter(
    locale = Locale.current,
    monthDisplayStyle = MonthDisplayStyle.SHORT,
    cjkSuffixConfig = CjkSuffixConfig.HideAll
  ),
  timeFormatter: TimeFormatter = timeFormatter(Locale.current),
  viewportSize: DpSize = DpSize(256.dp, 128.dp),
  rowCount: Int = 3,
  textStyle: TextStyle = MaterialTheme.typography.titleMedium,
  textColor: Color = LocalContentColor.current,
  selectedTextStyle: TextStyle = textStyle,
  selectedTextColor: Color = textColor,
  selectorProperties: SelectorProperties = WheelPickerDefaults.selectorProperties(),
  onSnappedDateTimeChanged: (snappedDateTime: SnappedDateTime) -> Unit = {},
  onSnappedDateTime: (snappedDateTime: SnappedDateTime) -> Int? = { _ -> null },
) {

  var snappedDateTime by remember { mutableStateOf(startDateTime.truncatedTo(ChronoUnit.MINUTES)) }

  val yearTexts = remember(yearsRange) { yearsRange?.map { it.toString() } ?: listOf() }

  Box(modifier = modifier, contentAlignment = Alignment.Center) {
    if (selectorProperties.enabled().value) {
      Surface(
        modifier = Modifier
          .size(viewportSize.width, viewportSize.height / rowCount),
        shape = selectorProperties.shape().value,
        color = selectorProperties.color().value,
        border = selectorProperties.border().value
      ) {}
    }
    Row {
      //Date
      AdaptiveWheelDatePicker(
        startDate = startDateTime.date,
        minDate = minDateTime.date,
        maxDate = maxDateTime.date,
        yearsRange = yearsRange,
        dateFormatter = dateFormatter,
        viewportSize = DpSize(
          width = if (yearsRange == null) viewportSize.width * 3 / 6 else viewportSize.width * 3 / 5,
          height = viewportSize.height
        ),
        rowCount = rowCount,
        textStyle = textStyle,
        textColor = textColor,
        selectedTextStyle = selectedTextStyle,
        selectedTextColor = selectedTextColor,
        selectorProperties = WheelPickerDefaults.selectorProperties(
          enabled = false
        ),
        onSnappedDate = { snappedDate ->

          val newDateTime = when (snappedDate) {
            is SnappedDate.DayOfMonth -> {
              snappedDateTime.withDayOfMonth(snappedDate.snappedLocalDate.day)
            }

            is SnappedDate.Month -> {
              snappedDateTime.withMonthNumber(snappedDate.snappedLocalDate.month.number)
            }

            is SnappedDate.Year -> {
              snappedDateTime.withYear(snappedDate.snappedLocalDate.year)
            }
          }

          if (!newDateTime.isBefore(minDateTime) && !newDateTime.isAfter(maxDateTime)) {
            snappedDateTime = newDateTime
          }

          return@AdaptiveWheelDatePicker when (snappedDate) {
            is SnappedDate.DayOfMonth -> {
              onSnappedDateTime(SnappedDateTime.DayOfMonth(snappedDateTime, snappedDateTime.day - 1))
              snappedDateTime.day - 1
            }

            is SnappedDate.Month -> {
              onSnappedDateTime(SnappedDateTime.Month(snappedDateTime, snappedDateTime.month.number - 1))
              snappedDateTime.month.number - 1
            }

            is SnappedDate.Year -> {
              val newYearTextIndex = yearTexts.indexOf(snappedDateTime.year.toString())
              onSnappedDateTime(SnappedDateTime.Year(snappedDateTime, newYearTextIndex))
              newYearTextIndex
            }
          }
        },
        onSnappedDateChanged = { snappedDate ->
          onSnappedDateTimeChanged(when (snappedDate) {
            is SnappedDate.DayOfMonth -> snappedDateTime.withDayOfMonth(snappedDate.snappedLocalDate.day)
              .let { SnappedDateTime.DayOfMonth(it, it.day - 1) }
            is SnappedDate.Month -> snappedDateTime.withMonthNumber(snappedDate.snappedLocalDate.month.number)
              .let { SnappedDateTime.Month(it, it.month.number - 1) }
            is SnappedDate.Year -> snappedDateTime.withYear(snappedDate.snappedLocalDate.year)
              .let { SnappedDateTime.Year(it, yearTexts.indexOf(it.year.toString())) }
          })
        }
      )
      //Time
      StandardWheelTimePicker(
        startTime = startDateTime.time,
        timeFormatter = timeFormatter,
        viewportSize = DpSize(
          width = if (yearsRange == null) viewportSize.width * 3 / 6 else viewportSize.width * 2 / 5,
          height = viewportSize.height
        ),
        rowCount = rowCount,
        textStyle = textStyle,
        textColor = textColor,
        selectedTextStyle = selectedTextStyle,
        selectedTextColor = selectedTextColor,
        selectorProperties = WheelPickerDefaults.selectorProperties(
          enabled = false
        ),
        onSnappedTime = { snappedTime, timeFormat ->

          val newDateTime = when (snappedTime) {
            is SnappedTime.Hour -> {
              snappedDateTime.withHour(snappedTime.snappedLocalTime.hour)
            }

            is SnappedTime.Minute -> {
              snappedDateTime.withMinute(snappedTime.snappedLocalTime.minute)
            }
          }

          if (!newDateTime.isBefore(minDateTime) && !newDateTime.isAfter(maxDateTime)) {
            snappedDateTime = newDateTime
          }

          return@StandardWheelTimePicker when (snappedTime) {
            is SnappedTime.Hour -> {
              onSnappedDateTime(SnappedDateTime.Hour(snappedDateTime, snappedDateTime.hour))
              if (timeFormat == TimeFormat.HOUR_24) snappedDateTime.hour else
                localTimeToAmPmHour(snappedDateTime.time) - 1
            }

            is SnappedTime.Minute -> {
              onSnappedDateTime(SnappedDateTime.Minute(snappedDateTime, snappedDateTime.minute))
              snappedDateTime.minute
            }
          }
        },
        onSnappedTimeChanged = { snappedTime, timeFormat ->
          onSnappedDateTimeChanged(when (snappedTime) {
            is SnappedTime.Hour -> snappedDateTime.withHour(snappedTime.snappedLocalTime.hour)
              .let { SnappedDateTime.Hour(it, if (timeFormat == TimeFormat.HOUR_24) it.hour else localTimeToAmPmHour(it.time) - 1) }
            is SnappedTime.Minute -> snappedDateTime.withMinute(snappedTime.snappedLocalTime.minute)
              .let { SnappedDateTime.Minute(it, it.minute) }
          })
        }
      )
    }
  }
}











