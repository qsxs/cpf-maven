package io.github.vinceglb.filekit.dialogs

import io.github.vinceglb.filekit.PlatformFile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.last
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.transform

/**
 * Defines the mode of the file picker (Single, Multiple, etc.) and handles result parsing.
 *
 * @param PickerResult The type of the result returned by the picker.
 * @param ConsumedResult The type of the result consumed by the callback.
 */
public sealed class FileKitMode<PickerResult, ConsumedResult> {
    internal abstract fun getPickerMode(): PickerMode

    internal abstract suspend fun parseResult(flow: Flow<FileKitPickerState<List<PlatformFile>>>): PickerResult

    public abstract suspend fun consumeResult(
        result: PickerResult,
        onConsumed: (ConsumedResult) -> Unit,
    )

    /**
     * Single file picker mode.
     */
    public data object Single : FileKitMode<PlatformFile?, PlatformFile?>() {
        override fun getPickerMode(): PickerMode = PickerMode.Single

        override suspend fun parseResult(flow: Flow<FileKitPickerState<List<PlatformFile>>>): PlatformFile? = flow.last().let {
            when (it) {
                is FileKitPickerState.Failed -> {
                    throw it.cause
                }

                is FileKitPickerState.Completed -> {
                    it.result.firstOrNull()
                }

                else -> {
                    null
                }
            }
        }

        override suspend fun consumeResult(
            result: PlatformFile?,
            onConsumed: (PlatformFile?) -> Unit,
        ) {
            onConsumed(result)
        }
    }

    /**
     * Multiple file picker mode.
     *
     * @property maxItems The maximum number of items to pick (1..50).
     * Native UI limits are platform-dependent (available on Android/iOS gallery pickers),
     * and FileKit always caps returned results to this value as a fallback.
     */
    public data class Multiple(
        val maxItems: Int? = null,
    ) : FileKitMode<List<PlatformFile>?, List<PlatformFile>?>() {
        override fun getPickerMode(): PickerMode = PickerMode.Multiple(maxItems)

        override suspend fun parseResult(flow: Flow<FileKitPickerState<List<PlatformFile>>>): List<PlatformFile>? = flow.last().let {
            when (it) {
                is FileKitPickerState.Failed -> {
                    throw it.cause
                }

                is FileKitPickerState.Completed -> {
                    val files = maxItems
                        ?.let { max -> it.result.take(max) }
                        ?: it.result
                    files.takeIfNotEmpty()
                }

                else -> {
                    null
                }
            }
        }

        override suspend fun consumeResult(
            result: List<PlatformFile>?,
            onConsumed: (List<PlatformFile>?) -> Unit,
        ) {
            onConsumed(result)
        }
    }

    /**
     * Single file picker mode exposing the state as a [Flow].
     */
    public data object SingleWithState :
        FileKitMode<Flow<FileKitPickerState<PlatformFile>>, FileKitPickerState<PlatformFile>>() {
        override fun getPickerMode(): PickerMode = PickerMode.Single

        override suspend fun parseResult(flow: Flow<FileKitPickerState<List<PlatformFile>>>): Flow<FileKitPickerState<PlatformFile>> = flow
            .transform { pickerState ->
                when (pickerState) {
                    is FileKitPickerState.Cancelled -> {
                        emit(FileKitPickerState.Cancelled)
                    }

                    is FileKitPickerState.Failed -> {
                        emit(FileKitPickerState.Failed(cause = pickerState.cause))
                    }

                    is FileKitPickerState.Started -> {
                        emit(FileKitPickerState.Started(total = pickerState.total))
                    }

                    is FileKitPickerState.Progress -> {
                        val file = pickerState.processed.firstOrNull()
                        if (file != null) {
                            emit(
                                FileKitPickerState.Progress(
                                    processed = file,
                                    total = pickerState.total,
                                ),
                            )
                        }
                    }

                    is FileKitPickerState.Completed -> {
                        val file = pickerState.result.firstOrNull()
                        when {
                            file != null -> emit(FileKitPickerState.Completed(result = file))
                            else -> emit(FileKitPickerState.Cancelled) // Treat empty result as cancellation
                        }
                    }
                }
            }

        override suspend fun consumeResult(
            result: Flow<FileKitPickerState<PlatformFile>>,
            onConsumed: (FileKitPickerState<PlatformFile>) -> Unit,
        ) {
            result.collect(onConsumed)
        }
    }

    /**
     * Multiple file picker mode exposing the state as a [Flow].
     *
     * @property maxItems The maximum number of items to pick (1..50).
     * Native UI limits are platform-dependent (available on Android/iOS gallery pickers),
     * and FileKit always caps emitted totals and lists to this value as a fallback.
     */
    public data class MultipleWithState(
        val maxItems: Int? = null,
    ) : FileKitMode<Flow<FileKitPickerState<List<PlatformFile>>>, FileKitPickerState<List<PlatformFile>>>() {
        override fun getPickerMode(): PickerMode = PickerMode.Multiple(maxItems)

        override suspend fun parseResult(
            flow: Flow<FileKitPickerState<List<PlatformFile>>>,
        ): Flow<FileKitPickerState<List<PlatformFile>>> = flow
            .mapNotNull { pickerState ->
                when (pickerState) {
                    is FileKitPickerState.Cancelled -> {
                        FileKitPickerState.Cancelled
                    }

                    is FileKitPickerState.Failed -> {
                        FileKitPickerState.Failed(cause = pickerState.cause)
                    }

                    is FileKitPickerState.Started -> {
                        FileKitPickerState.Started(
                            total = maxItems?.let { max -> minOf(pickerState.total, max) } ?: pickerState.total,
                        )
                    }

                    is FileKitPickerState.Progress -> {
                        FileKitPickerState.Progress(
                            processed = maxItems?.let { max -> pickerState.processed.take(max) } ?: pickerState.processed,
                            total = maxItems?.let { max -> minOf(pickerState.total, max) } ?: pickerState.total,
                        )
                    }

                    is FileKitPickerState.Completed -> {
                        val files = (
                            maxItems?.let { max -> pickerState.result.take(max) }
                                ?: pickerState.result
                        ).takeIfNotEmpty()

                        when {
                            files != null -> FileKitPickerState.Completed(result = files)
                            else -> FileKitPickerState.Cancelled
                        }
                    }
                }
            }

        override suspend fun consumeResult(
            result: Flow<FileKitPickerState<List<PlatformFile>>>,
            onConsumed: (FileKitPickerState<List<PlatformFile>>) -> Unit,
        ) {
            result.collect(onConsumed)
        }
    }
}

private fun List<PlatformFile>.takeIfNotEmpty(): List<PlatformFile>? = takeIf { it.isNotEmpty() }

internal sealed class PickerMode {
    data object Single : PickerMode()

    data class Multiple(
        val maxItems: Int? = null,
    ) : PickerMode() {
        init {
            require(maxItems == null || maxItems in 1..50) {
                "maxItems must be contained between 1 <= maxItems <= 50 but current value is $maxItems"
            }
        }
    }
}
