/*
 * Copyright 2014-2026 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package io.ktor.client.engine.curl

import io.ktor.client.engine.curl.CurlTask.*
import io.ktor.client.engine.curl.internal.*
import kotlinx.atomicfu.atomic
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.IntVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.cancellation.CancellationException

@OptIn(ExperimentalForeignApi::class)
internal class CurlProcessor(coroutineContext: CoroutineContext) {

    @OptIn(DelicateCoroutinesApi::class, ExperimentalCoroutinesApi::class)
    private val curlDispatcher = newSingleThreadContext("curl-dispatcher")

    private var curlApi: CurlMultiApiHandler? by atomic(null)
    private val closed = atomic(false)

    private val curlScope = CoroutineScope(coroutineContext + curlDispatcher)
    private val taskQueue: Channel<CurlTask> = Channel(Channel.UNLIMITED)

    init {
        val init = curlScope.launch {
            curlApi = CurlMultiApiHandler()
        }

        runBlocking {
            init.join()
        }

        runEventLoop().invokeOnCompletion { cause ->
            cause?.let { curlScope.cancel(cause = cause as? CancellationException ?: CancellationException(cause)) }
        }
    }

    suspend fun executeRequest(request: CurlRequestData): CurlSuccess {
        val result = CompletableDeferred<CurlSuccess>()
        taskQueue.send(SendRequest(request, result))
        curlApi!!.wakeup()
        return result.await()
    }

    suspend fun sendWebSocketFrame(websocket: CurlWebSocketResponseBody, flags: Int, data: ByteArray) {
        val result = Job()
        taskQueue.send(SendWebSocketFrame(websocket, flags, data, result))
        curlApi!!.wakeup()
        result.join()
    }

    /**
     * Cancels a WebSocket easy handle by enqueuing a cancellation task.
     * Called when a WebSocket session is closed to ensure the curl easy handle
     * is removed from the multi handle, preventing stale handles from blocking
     * the event loop.
     */
    fun cancelWebSocket(websocket: CurlWebSocketResponseBody) {
        val sent = taskQueue.trySend(CancelWebSocket(websocket))
        if (sent.isSuccess) {
            curlApi!!.wakeup()
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun runEventLoop(): Job = curlScope.launch(CoroutineName("curl-processor-loop")) {
        memScoped {
            val transfersRunning = alloc<IntVar>()
            val api = curlApi!!
            while (!taskQueue.isClosedForReceive) {
                drainTaskQueue(api)
                api.perform(transfersRunning)
            }
        }
    }

    private suspend fun drainTaskQueue(api: CurlMultiApiHandler) {
        while (true) {
            val task = if (api.hasHandlers()) {
                taskQueue.tryReceive()
            } else {
                taskQueue.receiveCatching()
            }.getOrNull() ?: break

            when (task) {
                is SendRequest -> handleSendRequest(api, task)

                is SendWebSocketFrame ->
                    api.sendWebSocketFrame(task.websocket, task.flags, task.data, task.completionHandler)

                is CancelWebSocket ->
                    api.cancelWebSocket(task.websocket, CancellationException("WebSocket session closed"))

                is CancelRequest -> api.cancelRequest(task.easyHandle, task.completionHandler, task.cause)
            }
        }
    }

    private fun handleSendRequest(api: CurlMultiApiHandler, task: SendRequest) {
        val (requestData, completionHandler) = task
        val requestHandler = api.scheduleRequest(requestData, completionHandler)

        val requestCleaner = requestData.callContext.invokeOnCompletion { cause ->
            if (cause == null) return@invokeOnCompletion
            cancelRequest(requestHandler, completionHandler, cause)
        }

        completionHandler.invokeOnCompletion {
            requestCleaner.dispose()
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    fun close() {
        if (!closed.compareAndSet(false, true)) return

        taskQueue.close()
        curlApi!!.wakeup()

        GlobalScope.launch(curlDispatcher) {
            curlScope.coroutineContext[Job]!!.join()
            curlApi!!.close()
        }.invokeOnCompletion {
            curlDispatcher.close()
        }
    }

    private fun cancelRequest(
        easyHandle: EasyHandle,
        completionHandler: CompletableDeferred<CurlSuccess>,
        cause: Throwable,
    ) {
        val sent = taskQueue.trySend(CancelRequest(easyHandle, completionHandler, cause))
        if (sent.isSuccess) {
            curlApi!!.wakeup()
        }
    }
}

private sealed interface CurlTask {

    data class SendRequest(
        val requestData: CurlRequestData,
        val completionHandler: CompletableDeferred<CurlSuccess>,
    ) : CurlTask

    class SendWebSocketFrame(
        val websocket: CurlWebSocketResponseBody,
        val flags: Int,
        val data: ByteArray,
        val completionHandler: CompletableJob,
    ) : CurlTask

    class CancelWebSocket(
        val websocket: CurlWebSocketResponseBody,
    ) : CurlTask

    @OptIn(ExperimentalForeignApi::class)
    class CancelRequest(
        val easyHandle: EasyHandle,
        val completionHandler: CompletableDeferred<CurlSuccess>,
        val cause: Throwable,
    ) : CurlTask
}
